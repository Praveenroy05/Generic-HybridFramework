	package com.hybridFramework.loginPage;
	
	
	import org.apache.log4j.Logger;
	
	import org.testng.Assert;
	
	import org.testng.annotations.Test;

import com.hybridFramework.PageObject.HomePage;
import com.hybridFramework.PageObject.LoginPage;
import com.hybridFramework.PageObject.LoginPage1;
import com.hybridFramework.helper.Logger.LoggerHelper;
	
	import com.hybridFramework.testBase.Config;
	
	import com.hybridFramework.testBase.TestBase;
	
	
	/**
	 * 
	 * @author Praveen Roy
	 *
	**/
	public class LoginTest1 extends TestBase
	{
		
	private final Logger log = LoggerHelper.getLogger(LoginTest1.class);
	
	LoginPage1 loginPage = new LoginPage1(driver);
	
	
	@Test(priority=1)
	public void validateAbhiBusLogoToolTipMsz()
	{
		Config config = new Config(OR);
		driver.get(config.getWebsite());
		/*String tooltip = loginPage.validateAbhiBusLogoToolTip();
		System.out.println(tooltip);
		
		//Assert.assertEquals(tooltip,"abhibus.com - India's Fastest Online bus ticket booking site");
*/	
		
		
	log.info(LoginTest1.class.getName()+" started");
			
	
			
	
					
	loginPage.homePageTicketSearch(config.getSource(), config.getDestination());
			
	
	
			
	/*if(status)
	{
			   
	log.info("login is sucessful");	
			
	}
			
	else
	{
				
	Assert.assertTrue(false, "login is not successful");
			
	}*/
		
	}
	
	
	}