package com.hybridFramework.PageObject;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.hybridFramework.helper.Javascript.JavaScriptHelper;
import com.hybridFramework.helper.Logger.LoggerHelper;
import com.hybridFramework.helper.Wait.WaitHelper;
import com.hybridFramework.helper.genericHelper.GenericHelper;
import com.hybridFramework.testBase.Config;
import com.hybridFramework.testBase.TestBase;

/**
 * 
 * @author Praveen Roy
 * 
 */
public class LoginPage1{
	
	//Page Factory - OR:
	
	WebDriver driver;
	private final Logger log = LoggerHelper.getLogger(LoginPage1.class);
	WaitHelper waitHelper;
	
	@FindBy(xpath="//img[contains(@title,'abhibus.com')]")
	WebElement abhibusLogo;
	
	@FindBy(xpath="//*[@name='source']")
	WebElement leavingFrom;
	
	@FindBy(xpath="//*[@name='destination']")
	WebElement goingTo;
	
	@FindBy(xpath="//*[@name='journey_date']")
	WebElement dateOfJourneyfield;
	
	@FindBy(xpath="(//table)[1]/tbody/tr[4]/td[5]")
	WebElement dateOfJourneyCalendar;
	
	@FindBy(xpath="//*[@name='journey_rdate']")
	WebElement returnDatefield;
	
	@FindBy(xpath="(//table)[2]/tbody/tr[3]/td[5]")
	WebElement dateOfReturnCalendar;
	
	@FindBy(xpath="//*[text()='Search']")
	WebElement searchBtn;
	

	public LoginPage1(WebDriver driver) 
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
		/*waitHelper = new WaitHelper(driver);
		waitHelper.waitForElement(driver, searchBtn,new Config(TestBase.OR).getExplicitWait());*/
	}
	
	
	public void enterSourceLocation(String sourceLocation)
	{
		log.info("entering source location...."+sourceLocation);
		this.leavingFrom.click();
		this.leavingFrom.sendKeys(sourceLocation);
	}
	
	public void enterDestination(String destinationLocation)
	{
		log.info("entering destination location...."+destinationLocation);
		this.goingTo.sendKeys(destinationLocation);
	}
	
	public void clickOnSearch()
	{
		log.info("clicked on search  button...");
		searchBtn.click();
	}
	
	
	/*public SeatSearch clickOnSubmitButton()
	{
		log.info("clicking on submit button...");
		new JavaScriptHelper(driver).scrollDownVertically();
		submitLogin.click();
		return new SeatSearch(driver);
	}*/
	
	public String validateAbhiBusLogoToolTip(){
		
		return abhibusLogo.getAttribute("title");
	}
	
	
	
	public void homePageTicketSearch(String sourceLocation, String destinationLocation)
	{
		
		enterSourceLocation(sourceLocation);
		enterDestination(destinationLocation);
		clickOnSearch();
	}

}
