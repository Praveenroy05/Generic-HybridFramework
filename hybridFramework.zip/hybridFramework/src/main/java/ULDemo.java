import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



public class ULDemo extends Thread{
	
	public static WebDriver driver;
	public static WebDriverWait wait;
	
	public void run()
	{
		try
		{
			Thread.sleep(100000);
			
			StringSelection username= new StringSelection("vchinthapatla@TAMS.COM");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username, null);
			
			Robot robot= new Robot();
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			
			Thread.sleep(5000);
			
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
			
			Thread.sleep(3000);
			
			StringSelection password= new StringSelection("PUP@37tent");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(password, null);
			
			
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_V);
			
			robot.keyRelease(KeyEvent.VK_V);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			
			Thread.sleep(3000);
			
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			
			Thread.sleep(2000);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	
	
	
	}
	
	
	
	@Test(priority=1)
	public void searchResultTest() throws InterruptedException
	{
		ULDemo parallel= new ULDemo();
		parallel.start();
		
		System.setProperty("webdriver.ie.driver", "E:\\Selenium\\seleniumHybridFramework-master\\drivers\\IEDriverServer.exe");	
		driver = new InternetExplorerDriver(); 
		
		
		driver.get("https://intranetqa.tams.com/VirtualApps/BUSOPSWebs/ULDemo/Reports/Summaries/Dashboard");
		
		wait= new WebDriverWait(driver,100);
		//Thread.sleep(100000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='New Demo Request']")));
		
		driver.findElement(By.xpath("//*[text()='New Demo Request']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@ng-bind='dataItem.ACCT_NAME'])[1]")));
		
		driver.findElement(By.xpath("(//span[@ng-bind='dataItem.ACCT_NAME'])[1]")).click();
		
		
		
	}

}
